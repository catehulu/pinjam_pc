@extends('layouts.app')

@section('content')
<div class="container">
    
    <div class="row">
    
        <div class="">
        <div style="margin-bottom: 20px">
            <td><a href="{{ route('data.createinventaris') }}" class="btn btn-primary">Tambah</a></td>
        </div>
             @if ($message = Session::get('success'))
                <div class="alert alert-success" style="margin:0px;text-align:center">
                    <p>{{ $message }}</p>
                </div>
            @endif
            <div class="card border-primary" style="">
            
                <div class="card-header">Daftar Inventaris</div>
                
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert" style="margin:0px;text-align:center">
                            {{ session('status') }}
                        </div>
                    @endif

                    @if ($data->isEmpty())
                        Tidak ada data
                    @else
                    <table class="center table table-striped table-inverse table-responsive">
                        <thead class="thead-black" align="center">
                            <tr>
                                <th>Nama Barang</th>
                                <th>Jumlah</th>
                                <th>Keterangan</th>
                                <th>Edit</th>
                                <th>Hapus</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                                @foreach ($data as $datas)
                                <tr>
                                    <td>{{ $datas->nama }}</td>
                                    <td>{{ $datas->NRP }}</td>
                                    <td>{{ $datas->Dosbing }}</td>
                                    <td><a href="{{ route('data.editinventaris',$datas->id) }}" class="btn btn-primary">Edit</a></td>
                                    <td><a href="{{ route('data.readone',$datas->id) }}" class="btn btn-danger">Hapus</a></td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                        {{ $data->links() }}
                        @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
